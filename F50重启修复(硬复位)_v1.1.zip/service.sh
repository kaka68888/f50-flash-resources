#!/system/bin/sh
# ============================================================================
# f50_reboot_fix —— 重启修复守护  v1.1
# 作用: 监听重启意图(sys.powerctl=reboot*)，在系统执行"干净关机"前，
#       抢先执行内核级硬复位(sysrq-b)，规避本机"关机卸载 /data,/cache 卡死"。
# 平台: 展锐 UMS9620 / Android 13 / F50 (MU300) / Magisk
# 作者: 酷安@瓜瓜腻
# ----------------------------------------------------------------------------
# v1.1 修复:
#   1) 单实例锁移到 tmpfs(/dev)，重启自动清空——原 /data 上的 daemon.pid
#      跨重启存活，重启后 kill -0 旧pid 会命中被复用 PID 的任意进程，
#      守护误判"已运行"而静默退出(与 f50_usbnet_guard 同款缺陷)。
#   2) 特殊重启原因放行: recovery/bootloader/fastboot/sideload/edl 等
#      走系统原流程——原版 sysrq-b 会把 adb reboot recovery 等全部变成
#      普通重启，破坏进 recovery/线刷的入口。未知原因仍拦截(记日志)。
#   3) 拦截/放行均落日志；module.prop 描述随拦截次数动态刷新(内容不变不重写)。
# ============================================================================
MODDIR=${0%/*}
DATA=/data/adb/f50_reboot_fix
LOG=$DATA/reboot.log
LOCKD=/dev/.f50_reboot_fix.lock.d
mkdir -p "$DATA"

log() { echo "[$(date '+%F %T')] $*" >> "$LOG" 2>/dev/null; }

# 动态刷新模块描述(内容不变不重写，避免无谓的 flash 写入)
update_desc() {
  prop="$MODDIR/module.prop"
  [ -f "$prop" ] || return 0
  c=$(cat "$DATA/count" 2>/dev/null); [ -z "$c" ] && c=0
  last=$(cat "$DATA/last" 2>/dev/null); [ -z "$last" ] && last="无"
  desc="【F50 重启修复 v1.1】守护=运行中 | 已拦截 ${c} 次 | 末次 ${last}"
  [ "$(grep '^description=' "$prop" 2>/dev/null | head -n 1)" = "description=$desc" ] && return 0
  grep -v '^description=' "$prop" > "$prop.tmp" 2>/dev/null
  echo "description=$desc" >> "$prop.tmp" 2>/dev/null
  mv "$prop.tmp" "$prop" 2>/dev/null
}

do_hard_reset() {   # $1=原因
  log "捕获重启意图 sys.powerctl=[$1] → 内核硬复位(sysrq-b)"
  c=$(cat "$DATA/count" 2>/dev/null); [ -z "$c" ] && c=0
  echo $((c+1)) > "$DATA/count"
  date '+%F %T' > "$DATA/last"
  update_desc
  echo 1 > /proc/sys/kernel/sysrq 2>/dev/null
  # 限时 sync: sync 卡住不能拖垮复位；剩余脏数据由文件系统日志回放兜底
  ( sync ) &
  sp=$!
  sleep 2
  kill -9 "$sp" 2>/dev/null
  echo b > /proc/sysrq-trigger
  # 正常不会到达这里；到达说明 sysrq 被内核禁用或写入失败
  log "!! sysrq-b 写入后系统仍在运行，放行原流程"
}

# 特殊重启原因: 放行走系统原流程(进 recovery/bootloader 等入口不能被破坏)
# 注意: 放行的原因如果也卡在干净关机，需要另行处理；如需调整改本列表
pass_through() {
  case "$1" in
    reboot,recovery|reboot,bootloader|reboot,fastboot|reboot,fastbootd|reboot,sideload|reboot,edl|reboot,download|reboot,safeboot|reboot,qemu) return 0 ;;
  esac
  return 1
}

# ---------------- 命令行(排障用) ----------------
case "$1" in
  --status)
    echo "== F50 重启修复 v1.1 (作者: 酷安@瓜瓜腻) =="
    echo "守护进程  : $(cat $LOCKD/pid 2>/dev/null || echo 未运行)"
    echo "拦截重启  : $(cat $DATA/count 2>/dev/null || echo 0) 次"
    echo "上次动作  : $(cat $DATA/last 2>/dev/null || echo 无)"
    echo "当前powerctl: [$(getprop sys.powerctl)]"
    echo "sysrq     : $(cat /proc/sys/kernel/sysrq 2>/dev/null)"
    echo "近期日志  :"
    tail -6 "$LOG" 2>/dev/null
    exit 0 ;;
  --reboot)
    log "手动硬复位"
    do_hard_reset "manual(--reboot)"
    exit 0 ;;
esac

# ---------------- 单实例(mkdir 原子锁; tmpfs 重启自动清空) ----------------
if ! mkdir "$LOCKD" 2>/dev/null; then
  old=$(cat "$LOCKD/pid" 2>/dev/null)
  if [ -n "$old" ] && kill -0 "$old" 2>/dev/null; then
    echo "daemon already running: $old"; exit 0
  fi
  rm -rf "$LOCKD"; mkdir "$LOCKD" 2>/dev/null
fi
echo $$ > "$LOCKD/pid"
chmod 700 "$LOCKD" 2>/dev/null
trap 'rm -rf "$LOCKD"; exit 0' TERM INT
rm -f "$DATA/daemon.pid"   # 清理 v1.0 遗留的 /data pid 文件(不再使用)

log "==== f50_reboot_fix v1.1 启动 (pid=$$) ===="

# 等系统启动完成
n=0
while [ "$n" -lt 120 ]; do
  [ "$(getprop sys.boot_completed)" = "1" ] && break
  sleep 2; n=$((n+2))
done
log "系统就绪，开始监听重启意图"
update_desc

last="$(getprop sys.powerctl)"

# 监听循环
while true; do
  cur="$(getprop sys.powerctl)"
  case "$cur" in
    reboot|reboot,*)
      if [ "$cur" != "$last" ]; then
        if pass_through "$cur"; then
          log "放行特殊重启 sys.powerctl=[$cur] → 走系统原流程"
        else
          do_hard_reset "$cur"
        fi
      fi
      ;;
  esac
  last="$cur"
  sleep 0.2
done
