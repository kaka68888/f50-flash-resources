#!/system/bin/sh
# action.sh —— Magisk 管理器里点"操作"按钮时执行
MODDIR=${0%/*}
sh "$MODDIR/service.sh" --status