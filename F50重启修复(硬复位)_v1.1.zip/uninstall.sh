#!/system/bin/sh
# uninstall.sh —— 卸载时执行
# v1.1: 补杀守护进程并清理 tmpfs 锁(原版只删数据目录，卸载后守护会一直活着拦截重启)
pkill -f "f50_reboot_fix/service.sh" 2>/dev/null
rm -rf /dev/.f50_reboot_fix.lock.d 2>/dev/null
rm -rf /data/adb/f50_reboot_fix 2>/dev/null
exit 0
