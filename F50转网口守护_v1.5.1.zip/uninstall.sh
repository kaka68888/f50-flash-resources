#!/system/bin/sh
# ============================================================================
# uninstall.sh —— 卸载时停止守护并清理
# (本模块不修改任何持久网络配置，无需回滚)
# 修复点: 原先引用了未定义的 $LOCK(变量根本不存在)，kill 永远不生效；
# 现改为 $LOCKD/pid(tmpfs 锁，随重启自动消失)，并补上锁目录清理。
# ============================================================================
MODDIR=${0%/*}
export MODDIR
. "$MODDIR/common.sh"

pid=$(cat "$LOCKD/pid" 2>/dev/null)
[ -n "$pid" ] && kill "$pid" 2>/dev/null
pkill -f "f50_usbnet_guard/service.sh" 2>/dev/null

rm -rf "$LOCKD"
rm -rf "$DATA_DIR"

echo "f50_usbnet_guard uninstalled at $(date)" >> /dev/kmsg 2>/dev/null
exit 0
