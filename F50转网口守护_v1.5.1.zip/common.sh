#!/system/bin/sh
# ============================================================================
# f50_usbnet_guard —— 公共库 (v1.5.0)
# 平台: 展锐 UMS9620 / Android 13 / F50 (MU300)
# 作者: 酷安@瓜瓜腻
# ----------------------------------------------------------------------------
# v1.5.0 修复要点(基于 guard.log + dmesg 实测, 2026-10-09):
#   [1] xhci 限流计数从 /dev/.f50_usbnet_guard.lock.d 移到 /data 持久化,
#       并以 /proc/sys/kernel/random/boot_id 区分"本次开机"。
#       原实现每次 runguard.sh 都会 rm -rf 锁目录 → 限流计数被清零而失效。
#   [2] log() 不再写 /dev/kmsg。模块自身依赖扫描 dmesg, 往 kmsg 灌日志会让
#       dmesg 无限膨胀 → 扫描越来越慢 → 巡检被拖垮(实测 270 次/148s 的
#       init gadget 重建把 kmsg 冲得只剩噪声)。
#   [3] usb_err_count() / m71 计数改为"每轮只扫一次 dmesg 并复用结果"。
#   [4] 新增 tx_packets() 与错误率判定所需的 TXERR_RATE / TXERR_MIN / PKT_MIN。
#   [5] reset_count 只统计"真正执行过 USB 复位"的次数(语义修正)。
#
# 保留 v1.3.x~v1.4.0 的全部既有功能与配置项，向后兼容。
# ============================================================================

MODVER="1.5.1"
export MODDIR="${MODDIR:-${0%/*}}"
DATA_DIR="/data/adb/f50_usbnet_guard"
LOG="$DATA_DIR/guard.log"
CONF="$DATA_DIR/config.conf"
LOCKD="/dev/.f50_usbnet_guard.lock.d"

# xHCI 重绑额度(每开机 1 次)。v1.5.0: 改用 /data 持久化 + boot_id 判开机，
# 不再依赖会被 runguard.sh 删除的 $LOCKD。
XHCI_TRIES="$DATA_DIR/xhci_tries"
XHCI_TRIES_BOOT="$DATA_DIR/xhci_tries.boot"

STATE="$DATA_DIR/state"
mkdir -p "$DATA_DIR" "$STATE" 2>/dev/null

# ---------------- 默认配置(可被 config.conf 覆盖) ----------------
USB_DEV="3-1"                 # USB 设备路径 /sys/bus/usb/devices/<USB_DEV>
IFACE="eth0"                  # 转网口
BRIDGE="br0"                  # 桥接口
BRIDGE_CIDR="192.168.5.1/24"  # br0 应拥有的地址
USB_XHCI="xhci-hcd.2.auto"    # xhci 控制器 platform 设备名(最后手段用)
USB_XHCI_DRV="xhci-hcd"       # xhci 控制器驱动名
BOOT_WAIT=180                 # 开机后等待网络就绪的最长时间(秒)
BOOT_GRACE=60                 # 开机后多少秒开始运行中巡检(秒)
POLL=15                       # 运行中巡检间隔(秒)
COOLDOWN=45                   # 两次恢复的最小间隔(秒)
TXERR_DELTA=50                # Tx 错误增量阈值(旧口径, 保留兼容)
# --- v1.5.0 新增: 错误率判定 ---
TXERR_RATE=5                  # 增量错误率阈值(%), 低于此值视为正常
TXERR_MIN=100                 # 触发判定的最小绝对错误数(防小流量误判)
PKT_MIN=5000                  # 触发判定的最小包数增量(防小流量误判)
AUTO_RESET=1                  # 是否自动恢复
KLOG_DETECT=1                 # 是否监控内核 USB 错误
KLOG_POLL=10                  # 内核错误轮询间隔(秒)
DHCP_RECOVER=0                # 是否允许"重启 netd"恢复 DHCP(较激进，默认关)
MEM_GUARD=1                   # 内存碎片守卫开关(v1.5.1: 逻辑增强, 见 service.sh)
MEM_ORDER3_MIN=30             # v1.5.1: DMA32 order-3 空闲块 <=此值即触发 compact(旧版硬编码 5, 太迟钝)
MEM_MIN_FREE=16384            # v1.5.1: min_free_kbytes(默认 4715 -> 16384, 给 GFP_ATOMIC 留余量)
MEM_WATERMARK_SCALE=50        # v1.5.1: watermark_scale_factor(默认 10 -> 50, 更早回收)
MEM_WATERMARK_BOOST=15000     # v1.5.1: watermark_boost_factor(默认 0 -> 15000, 碎片后抬水位)
MEM_PERSIST=1                 # v1.5.1: 定期重申以上 vm 参数(防被系统/其它模块改回)
AUTOSUSPEND_OFF=1             # 对 eth0/USB 设备关闭 USB 自动挂起(Runtime PM)
USBDEVFS_RESET=1              # 恢复链启用 USBDEVFS_RESET(需 bin/usbreset)
USB_POWER_CYCLE=1             # 恢复链启用 USB 端口电源循环(hub PORT_POWER)
KMSG_LOG=0                    # v1.5.0: 是否把模块日志写进 /dev/kmsg(默认关)

load_conf() {
  [ -f "$CONF" ] || return 0
  while IFS='=' read -r k v; do
    case "$k" in ''|\#*) continue ;; esac
    v=${v%%#*}
    v=$(echo "$v" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    eval "$k=\$v" 2>/dev/null
  done < "$CONF"
}

# v1.5.0: 不再默认写 /dev/kmsg。模块靠扫描 dmesg 找 Tx-71，自身往 kmsg 灌日志
# 会污染输入源并拖慢巡检；需要内核侧排查时把 config.conf 里 KMSG_LOG 改 1。
log() {
  echo "[$(date '+%F %T')] $*" >> "$LOG" 2>/dev/null
  [ "${KMSG_LOG:-0}" = "1" ] && echo "f50_usbnet_guard: $*" >> /dev/kmsg 2>/dev/null
  return 0
}

# ---------------- 状态探测 ----------------
dev_exists()     { [ -e "/sys/bus/usb/devices/$USB_DEV/authorized" ]; }
dev_authorized() { cat "/sys/bus/usb/devices/$USB_DEV/authorized" 2>/dev/null; }
iface_exists()   { [ -e "/sys/class/net/$IFACE" ]; }
iface_up()       { [ "$(cat "/sys/class/net/$IFACE/operstate" 2>/dev/null)" = "up" ]; }
iface_carrier()  { cat "/sys/class/net/$IFACE/carrier" 2>/dev/null; }
in_bridge()      { [ -e "/sys/class/net/$BRIDGE/brif/$IFACE" ]; }
tx_errors()      { cat "/sys/class/net/$IFACE/statistics/tx_errors" 2>/dev/null; }
# v1.5.0 新增: 配套 tx_errors 做错误率判定，避免只看绝对增量误判
tx_packets()     { cat "/sys/class/net/$IFACE/statistics/tx_packets" 2>/dev/null; }
ip4_of()         { echo "${1%%/*}"; }
br0_has_ip()     { ip -o addr show "$BRIDGE" 2>/dev/null | grep -q "$(ip4_of "$BRIDGE_CIDR")"; }
dhcp_pid()       { pidof dnsmasq 2>/dev/null | head -1; }
ip_fwd_ok()      { [ "$(cat /proc/sys/net/ipv4/ip_forward 2>/dev/null)" = "1" ]; }
usb_err_count()  { dmesg 2>/dev/null | grep -acE 'r8152.*Tx status -71|usb 3-1: reset SuperSpeed'; }

# 网口"半死": 存在但 carrier 读不到(carrier 文件为空) → 需要复位
iface_broken() {
  iface_exists || return 1
  [ -z "$(iface_carrier)" ] && return 0
  return 1
}
# 网口可用: carrier=1 (物理链路已建立)
iface_link_ok() { [ "$(iface_carrier)" = "1" ]; }

# ---------------- 内存调优 (v1.5.1) ----------------
# 根因: r8152 收包在软中断(NAPI)里申请 order-3(32KB) 的 GFP_ATOMIC 连续内存;
#       1.5GB 内存 + 紧张/碎片化时分配失败 → rx_bottom 崩 → 网卡掉 carrier。
# 对策: 抬高保留水位 + 更早回收 + 碎片后自动抬水位。三者互补。
_vm_write() {         # $1=path $2=val  返回 0=已改 1=本已最新 2=失败
  f="$1"; v="$2"
  [ -e "$f" ] || return 2
  [ "$(cat "$f" 2>/dev/null)" = "$v" ] && return 1
  echo "$v" > "$f" 2>/dev/null
  [ "$(cat "$f" 2>/dev/null)" = "$v" ] && return 0
  return 2
}
apply_mem_tuning() {
  [ "$MEM_GUARD" = "1" ] || return 0
  changed=""
  _vm_write /proc/sys/vm/min_free_kbytes      "$MEM_MIN_FREE"        && changed="$changed min_free_kbytes=$MEM_MIN_FREE"
  _vm_write /proc/sys/vm/watermark_scale_factor "$MEM_WATERMARK_SCALE" && changed="$changed wsf=$MEM_WATERMARK_SCALE"
  _vm_write /proc/sys/vm/watermark_boost_factor "$MEM_WATERMARK_BOOST" && changed="$changed wbf=$MEM_WATERMARK_BOOST"
  [ -n "$changed" ] && log "内存调优已应用:$changed"
  return 0
}
mem_order3() {  # DMA32 的 order-3 空闲块数(r8152 收包所需)
  grep -a 'zone *DMA32' /proc/buddyinfo 2>/dev/null | sed 's/.*DMA32 *//' | tr -s ' ' ' ' | cut -d' ' -f4
}
mem_order3_max() { # 全部 zone 的 order-3 最大值(兜底)
  awk '{print $6}' /proc/buddyinfo 2>/dev/null | sort -rn | head -1
}
page_alloc_fail() { dmesg 2>/dev/null | grep -ac 'page allocation failure'; }

# ---------------- 关闭 USB 自动挂起(Runtime PM) ----------------
autosuspend_paths() {
  echo "/sys/bus/usb/devices/$USB_DEV/power/control"
  echo "/sys/bus/usb/devices/usb${USB_DEV%%-*}/power/control"
  echo "/sys/class/net/$IFACE/device/power/control"
}
disable_autosuspend() {
  [ "$AUTOSUSPEND_OFF" = "1" ] || return 0
  changed=0
  for c in $(autosuspend_paths); do
    [ -e "$c" ] || continue
    if [ "$(cat "$c" 2>/dev/null)" != "on" ]; then
      echo on > "$c" 2>/dev/null && changed=1
    fi
    d="${c%/*}/autosuspend_delay_ms"
    [ -e "$d" ] && echo -1 > "$d" 2>/dev/null
  done
  [ "$changed" = "1" ] && log "已关闭 USB 自动挂起(autosuspend): $IFACE / $USB_DEV"
  return 0
}
autosuspend_state() { cat "/sys/bus/usb/devices/$USB_DEV/power/control" 2>/dev/null; }

# ---------------- usbreset: USBDEVFS_RESET / 端口电源循环 ----------------
USBRESET="$MODDIR/bin/usbreset"
has_usbreset() { [ -x "$USBRESET" ]; }
run_usbreset() {
  out=$("$USBRESET" "$@" 2>&1); rc=$?
  [ -n "$out" ] && log "  usbreset[$rc]: $out"
  return $rc
}
usbdevfs_reset() {
  [ "$USBDEVFS_RESET" = "1" ] || return 1
  has_usbreset || { log "未找到 bin/usbreset，跳过 USBDEVFS_RESET"; return 1; }
  log "USBDEVFS_RESET: $USB_DEV"
  run_usbreset --dev "$USB_DEV"
}
parent_hub_port() {
  case "$USB_DEV" in
    *.*) pp="${USB_DEV%.*}"; port="${USB_DEV##*.}" ;;
    *)   pp="usb${USB_DEV%%-*}"; port="${USB_DEV##*-}" ;;
  esac
  d="/sys/bus/usb/devices/$pp"
  [ -d "$d" ] || return 1
  b=$(cat "$d/busnum" 2>/dev/null); n=$(cat "$d/devnum" 2>/dev/null)
  [ -n "$b" ] && [ -n "$n" ] || return 1
  printf "/dev/bus/usb/%03d/%03d %s" "$b" "$n" "$port"
}
usb_power_cycle() {
  [ "$USB_POWER_CYCLE" = "1" ] || return 1
  has_usbreset || { log "未找到 bin/usbreset，跳过端口电源循环"; return 1; }
  hp=$(parent_hub_port) || { log "无法解析父 hub/端口，跳过电源循环"; return 1; }
  hubdev=${hp% *}; port=${hp# *}
  run_usbreset --ppps "$hubdev"
  log "USB 端口电源循环: hub=$hubdev port=$port"
  run_usbreset --power "$hubdev" "$port"
}

# ---------------- 复位动作 ----------------
reset_authorized() {
  dev_exists || return 1
  log "USB 软复位: authorized 0->1 ($USB_DEV)"
  echo 0 > "/sys/bus/usb/devices/$USB_DEV/authorized" 2>/dev/null
  sleep 2
  echo 1 > "/sys/bus/usb/devices/$USB_DEV/authorized" 2>/dev/null
}
reset_r8152() {
  log "USB 驱动重绑: r8152 unbind/bind ($USB_DEV:1.0)"
  echo "$USB_DEV:1.0" > /sys/bus/usb/drivers/r8152/unbind 2>/dev/null
  sleep 2
  echo "$USB_DEV:1.0" > /sys/bus/usb/drivers/r8152/bind 2>/dev/null
}

# v1.5.0: 限流计数持久化到 /data，并用 boot_id 判定"本次开机"。
# 原实现把计数放在 $LOCKD(=LOCKD/xhci_tries)，而 runguard.sh 每次启动守护都会
# rm -rf "$LOCKD"，计数随之清零 → 每开机 1 次的限流形同虚设。
xhci_tries_boot() {
  sig=$(cat /proc/sys/kernel/random/boot_id 2>/dev/null)
  [ -n "$sig" ] || sig=$(cat /proc/uptime 2>/dev/null | cut -d' ' -f1)
  cur=$(cat "$XHCI_TRIES_BOOT" 2>/dev/null)
  if [ "$cur" != "$sig" ]; then
    echo "$sig" > "$XHCI_TRIES_BOOT" 2>/dev/null
    echo 0 > "$XHCI_TRIES" 2>/dev/null
    echo 0
  else
    cat "$XHCI_TRIES" 2>/dev/null || echo 0
  fi
}

reset_xhci() {
  n=$(xhci_tries_boot); [ -z "$n" ] && n=0
  if [ "$n" -ge 1 ]; then
    log "xHCI 重绑本开机已尝试 $n 次，不再尝试(防内核挂死)"
    return 1
  fi
  echo $((n+1)) > "$XHCI_TRIES" 2>/dev/null
  log "USB 控制器重绑: $USB_XHCI unbind/bind (强制重新枚举总线, 本开机第 $((n+1))/1 次)"
  echo "$USB_XHCI" > "/sys/bus/platform/drivers/$USB_XHCI_DRV/unbind" 2>/dev/null
  sleep 3
  echo "$USB_XHCI" > "/sys/bus/platform/drivers/$USB_XHCI_DRV/bind" 2>/dev/null
}

wait_carrier() {
  n=0
  while [ "$n" -lt "$1" ]; do
    iface_link_ok && return 0
    sleep 2; n=$((n+2))
  done
  return 1
}
wait_iface() {
  n=0
  while [ "$n" -lt "$1" ]; do iface_exists && return 0; sleep 1; n=$((n+1)); done
  return 1
}

fix_bridge() {
  iface_exists || return 1
  ip link set "$IFACE" up 2>/dev/null
  if ! in_bridge; then
    ip link set "$IFACE" master "$BRIDGE" 2>/dev/null
    log "已把 $IFACE 挂回 $BRIDGE"
  fi
}
recover_bridge_ip() {
  ip link set "$BRIDGE" up 2>/dev/null
  if ! br0_has_ip; then
    ip addr add "$BRIDGE_CIDR" dev "$BRIDGE" 2>/dev/null
    log "补设 $BRIDGE 地址 $BRIDGE_CIDR"
  fi
}
recover_forward() {
  ip_fwd_ok || { echo 1 > /proc/sys/net/ipv4/ip_forward 2>/dev/null; log "开启 ip_forward"; }
}
recover_dhcp() {
  [ "$DHCP_RECOVER" = "1" ] || { log "DHCP(dnsmasq) 缺失，未启用自动恢复(DHCP_RECOVER=0)"; return 1; }
  log "尝试重启 netd 以重建 DHCP ..."
  setprop ctl.restart netd 2>/dev/null
  sleep 12
}

# v1.5.0: 记录"真实复位"次数——只有真正动过 USB 才计数。
# 旧版把每次 do_recover(含仅补桥接/补IP 的轻量动作)都计入 reset_count，
# 实测 41 次里绝大多数是 Tx 错误误判，实际 USB 复位为 0，语义失真。
note_real_reset() {
  n=$(cat "$DATA_DIR/reset_count" 2>/dev/null); [ -z "$n" ] && n=0
  echo "$((n+1))" > "$DATA_DIR/reset_count" 2>/dev/null
}

# 网口恢复链：软复位 → USBDEVFS → 端口电源循环 → 驱动重绑 → 控制器重绑
recover_iface() {
  if ! iface_link_ok; then
    if reset_authorized; then
      wait_carrier 20 && { note_real_reset; return 0; }
    fi
    log "软复位未成，升级到 USBDEVFS_RESET"
    if usbdevfs_reset; then
      wait_iface 15 && wait_carrier 20 && { note_real_reset; return 0; }
    fi
    log "USBDEVFS_RESET 未成，升级到端口电源循环"
    if usb_power_cycle; then
      wait_iface 20 && wait_carrier 20 && { note_real_reset; return 0; }
    fi
    log "电源循环未成，升级到驱动重绑"
    if reset_r8152; then
      wait_carrier 20 && { note_real_reset; return 0; }
    fi
    log "驱动重绑未成，升级到控制器重绑"
    if reset_xhci; then
      wait_iface 30 && wait_carrier 20 && { note_real_reset; return 0; }
    fi
    log "网口恢复失败"
    return 1
  fi
  return 0
}

# ---------------- 恢复主流程 ----------------
do_recover() {
  reason="$1"
  # 网口消失 + 本开机 xHCI 重绑额度已用完 → 每 10 分钟提醒一次，等待手动断电
  if ! iface_exists; then
    n=$(xhci_tries_boot); [ -z "$n" ] && n=0
    if [ "$n" -ge 1 ]; then
      now=$(date +%s)
      lg=$(cat "$DATA_DIR/last_giveup_log" 2>/dev/null); [ -z "$lg" ] && lg=0
      if [ "$((now - lg))" -ge 600 ]; then
        echo "$now" > "$DATA_DIR/last_giveup_log"
        log "USB 硬件故障: 软件恢复手段已用尽(xHCI 重绑本开机限 1 次) — 请手动断电重启"
        update_description
      fi
      return 2
    fi
  fi
  now=$(date +%s)
  last=$(cat "$DATA_DIR/last_reset" 2>/dev/null); [ -z "$last" ] && last=0
  if [ "$((now - last))" -lt "$COOLDOWN" ]; then
    log "冷却期内($((now-last))s < ${COOLDOWN}s)，跳过，下一轮再看"
    return 2
  fi
  log "==== 触发恢复: $reason ===="

  # v1.5.0: 先记时间戳再动作。实际复位计数由 recover_iface 自行累加，
  # 只有真正动过 USB 才写 last_reset，避免"只做桥接补IP"也被算成复位。
  echo "$now" > "$DATA_DIR/last_reset"

  recover_iface
  fix_bridge
  recover_bridge_ip
  recover_forward
  disable_autosuspend
  if ! dhcp_pid >/dev/null; then recover_dhcp; fi

  update_description
}

# ---------------- 动态刷新模块描述 ----------------
update_description() {
  prop="$MODDIR/module.prop"
  [ -f "$prop" ] || return 0
  st="正常"
  if ! iface_exists; then st="网口丢失!"
  elif iface_broken; then st="网口半死"
  elif ! iface_link_ok; then st="无链路"
  elif ! in_bridge; then st="未桥接"
  elif ! br0_has_ip; then st="br0无IP"
  elif ! dhcp_pid >/dev/null; then st="DHCP缺失"
  fi
  cnt=$(cat "$DATA_DIR/reset_count" 2>/dev/null); [ -z "$cnt" ] && cnt=0
  last=$(cat "$DATA_DIR/last_reset" 2>/dev/null)
  ts="无"; [ -n "$last" ] && ts=$(date -d "@$last" '+%m-%d %H:%M' 2>/dev/null)
  desc="【F50 转网口守护 v$MODVER】状态=$st | $IFACE@$BRIDGE | 真实复位 ${cnt} 次 | 末次 $ts"
  if [ "$(grep '^description=' "$prop" 2>/dev/null | head -n 1)" = "description=$desc" ]; then
    return 0
  fi
  grep -v '^description=' "$prop" > "$prop.tmp" 2>/dev/null
  echo "description=$desc" >> "$prop.tmp" 2>/dev/null
  mv "$prop.tmp" "$prop" 2>/dev/null
}

# ---------------- 状态总览 ----------------
show_status() {
  echo "== F50 转网口守护 v$MODVER (作者: 酷安@瓜瓜腻) =="
  echo "USB 设备    : $USB_DEV  exists=$(dev_exists && echo yes || echo no)  authorized=$(dev_authorized)"
  echo "网口        : $IFACE  exists=$(iface_exists && echo yes || echo no)  carrier=$(iface_carrier)  up=$(iface_up && echo yes || echo no)  speed=$(cat /sys/class/net/$IFACE/speed 2>/dev/null)"
  echo "桥接口      : $BRIDGE  member=$(in_bridge && echo yes || echo no)  ip=$(ip -o addr show "$BRIDGE" 2>/dev/null | awk '/inet /{print $4; exit}')"
  echo "DHCP(dnsmasq): pid=$(dhcp_pid)"
  echo "ip_forward  : $(cat /proc/sys/net/ipv4/ip_forward 2>/dev/null)"
  echo "Tx 统计     : errors=$(tx_errors) / packets=$(tx_packets)"
  echo "内核USB错误 : $(usb_err_count)"
  echo "USB自动挂起 : $(autosuspend_state) (期望 on=已关闭)   工具usbreset: $(has_usbreset && echo 有 || echo 缺失)"
  echo "真实复位次数: $(cat "$DATA_DIR/reset_count" 2>/dev/null)"
  echo "xHCI额度    : 本开机已用 $(xhci_tries_boot)/1"
  last=$(cat "$DATA_DIR/last_reset" 2>/dev/null)
  echo "末次恢复    : $( [ -n "$last" ] && date -d "@$last" '+%F %T' 2>/dev/null || echo 无 )"
  echo "内存调优    : min_free=$(cat /proc/sys/vm/min_free_kbytes 2>/dev/null) wsf=$(cat /proc/sys/vm/watermark_scale_factor 2>/dev/null) wbf=$(cat /proc/sys/vm/watermark_boost_factor 2>/dev/null) | DMA32 order-3=$(mem_order3) (阈值${MEM_ORDER3_MIN}) | alloc_fail累计=$(page_alloc_fail)"
  echo "参数        : 巡检=${POLL}s 冷却=${COOLDOWN}s 错误率阈值=${TXERR_RATE}% Tx阈值=${TXERR_DELTA}"
  echo "守护进程    : $(cat "$LOCKD/pid" 2>/dev/null)"
}