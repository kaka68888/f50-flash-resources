#!/system/bin/sh
# customize.sh —— 安装时在设备上执行(set_default_perm 之后运行，所以这里的 chmod 有效)
SKIPUNZIP=0

MODNAME=$(grep '^name=' "$MODPATH/module.prop" | cut -d= -f2-)
MODVER=$(grep '^version=' "$MODPATH/module.prop" | cut -d= -f2-)

ui_print "======================"
ui_print " $MODNAME"
ui_print " $MODVER"
ui_print "======================"
ui_print ""

# ---- 平台校验(只提示，不阻断) ----
UI_VER=$(getprop ro.build.version.release)
DEV=$(getprop ro.product.device)
MOD=$(getprop ro.product.model)
ui_print "- 系统: Android $UI_VER"
ui_print "- 机型: $MOD ($DEV)"
case "$MOD" in
  F50|MU300) ui_print "- 已知适配机型 OK" ;;
  *) ui_print "! 非已知适配机型(F50/MU300)，如异常请改 config.conf 里的 USB_DEV / USB_XHCI" ;;
esac

if [ -d /sys/bus/usb/drivers/r8152 ]; then
  ui_print "- r8152 驱动 OK"
else
  ui_print "! 未找到 r8152 驱动，转网口可能不可用"
fi
if [ -e /sys/class/net/br0 ]; then
  ui_print "- 桥接口 br0 OK"
else
  ui_print "! 未找到 br0"
fi

# ---- 升级: 先停旧守护，避免安装期间重复写 sysfs ----
if [ -f /data/adb/modules/f50_usbnet_guard/service.sh ]; then
  ui_print "- 检测到已安装版本，覆盖升级"
  pkill -f "f50_usbnet_guard/service.sh" 2>/dev/null
  sleep 1
fi
pkill -f "longterm_monitor" 2>/dev/null
rm -rf /dev/.f50_usbnet_guard.lock.d 2>/dev/null

# ---- 恢复备份里的用户配置(只在目标不存在时写入，不覆盖已调好的) ----
if [ -f "$MODPATH/config.conf" ] && [ ! -f /data/adb/f50_usbnet_guard/config.conf ]; then
  mkdir -p /data/adb/f50_usbnet_guard 2>/dev/null
  cp -f "$MODPATH/config.conf" /data/adb/f50_usbnet_guard/config.conf 2>/dev/null
  ui_print "- 已恢复备份中的 config.conf"
fi

# ---- 权限(必须，set_default_perm 会把文件刷成 0644) ----
chmod 755 "$MODPATH/service.sh" "$MODPATH/common.sh" "$MODPATH/post-fs-data.sh" 2>/dev/null
chmod 755 "$MODPATH/action.sh" "$MODPATH/uninstall.sh" 2>/dev/null
chmod 755 "$MODPATH/longterm_monitor.sh" "$MODPATH/longterm_report.sh" 2>/dev/null
[ -f "$MODPATH/bin/usbreset" ] && chmod 755 "$MODPATH/bin/usbreset" 2>/dev/null
ui_print "- 权限设置完成"

ui_print ""
ui_print "- 安装完成，重启后生效"
ui_print "  查看状态: sh /data/adb/modules/f50_usbnet_guard/service.sh --status"
