#!/system/bin/sh
# ============================================================================
# action.sh —— Magisk「操作」按钮：显示状态，并支持一键恢复
# ============================================================================
MODDIR=${0%/*}
export MODDIR
. "$MODDIR/common.sh"
load_conf

show_status
echo
echo "----------------------------------------"
echo "如需立即复位转网口(会短暂断网几秒)，执行:"
echo "  su -c 'sh $MODDIR/service.sh --recover'"