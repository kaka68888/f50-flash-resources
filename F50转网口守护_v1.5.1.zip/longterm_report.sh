#!/system/bin/sh
# 长期监测报告分析
D=/data/adb/f50_usbnet_guard
OUT=$D/longterm.log
echo "########## 长期监测报告 ##########"
echo "  监控进程: [$(pgrep -f longterm.sh | tr '\n' ' ')]"
echo "  采样行数: $(wc -l < $OUT 2>/dev/null)"
echo "  起始: $(head -2 $OUT | tail -1 | cut -d'|' -f1)"
echo "  结束: $(tail -1 $OUT | cut -d'|' -f1)"
echo
echo "===== 1. 采样间隔与实际覆盖时长 ====="
awk -F'|' 'NR>1{t=substr($1,12,8); if(p!=""){split(t,a,":");split(p,b,":");d=(a[1]*3600+a[2]*60+a[3])-(b[1]*3600+b[2]*60+b[3]); s+=d; n++} p=t} END{printf "  样本=%d  平均间隔=%.0f秒  总覆盖=%.0f秒(%.1f分钟)\n", n, s/n, s, s/60}' $OUT
echo
echo "===== 2. USB reset SuperSpeed 累积趋势 ====="
awk -F'|' 'NR>1{split($2,a,"=");print a[2]}' $OUT | awk 'NR==1{f=$1} {v=$1; if(v<last){printf "  %s  累积=%-5s (缓冲区滚动保护)\n",t,$1; next} printf "  %s  累积=%-5s (增%d)\n",t,$1,$1-l; last=$1}' 2>/dev/null | head -n 40
echo
echo "===== 3. Tx status -71 累积趋势 ====="
awk -F'|' 'NR>1{split($3,a,"=");print a[2]}' $OUT | head -n 40 | tr '\n' ' '
echo
echo
echo "===== 4. 网卡重建事件 (ifindex 变化) ====="
awk -F'|' 'NR>1 && $4 ~ /\(1\)/{print "  "$1"  "$4}' $OUT
n=$(awk -F'|' 'NR>1 && $4 ~ /\(1\)/' $OUT | wc -l)
echo "  >>> 重建总次数 = $n"
echo
echo "===== 5. carrier 变化事件 ====="
awk -F'|' 'NR>1 && $5 ~ /\(1\)/{print "  "$1"  "$5}' $OUT
echo
echo "===== 6. 速率与错误率 ====="
awk -F'|' 'NR>1{
  split($6,pk,"="); split($7,dd,"="); split($8,ee,"=");
  if(dd[2]>0) printf "  %s  pkt=%-8s 增量=%-6s tx_err=%-6s 增量错误率=%.3f%%\n", $1, pk[2], dd[2], ee[2], ee[2]*100/dd[2];
}' $OUT | tail -n 20
echo
echo "===== 7. 物理层错误累计 (tx_carrier / rx_errors / drop) ====="
awk -F'|' 'NR>1{split($9,c,"=");split($10,r,"=");split($11,d,"=");print "  "$1"  carrier_err="$9"  rx_err="$10"  drop="$11}' $OUT | tail -n 12
echo
echo "===== 8. br0 桥接成员变化 ====="
awk -F'|' 'NR>1{split($12,b,"="); if(b[2]!=pb){print "  "$1"  "$12; pb=b[2]}}' $OUT
echo
echo "===== 9. 平均速率/错误率汇总 ====="
awk -F'|' 'NR>1{
  split($6,pk,"="); split($7,dd,"="); split($8,ee,"="); split($2,r,"="); split($3,t,"=");
  if(dd[2]>0){n++; sp+=dd[2]; er+=ee[2]; if(r[2]>lr){lr=r[2]}} if(t[2]>lt){lt=t[2]}
} END{
  printf "  有效样本=%d\n", n;
  if(n>0){
    printf "  平均每区间发包=%.0f\n", sp/n;
    printf "  平均区间错误率=%.4f%%\n", (sp>0? er*100/sp : 0);
  }
}' $OUT
echo
echo "===== 10. 守护日志联动(最近) ====="
tail -n 6 $D/guard.log