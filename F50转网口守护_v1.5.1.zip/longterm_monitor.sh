#!/system/bin/sh
# ============================================================================
# f50_usbnet_guard 长期监测器(独立后台进程)
#   - 单调累加 dmesg 计数，抵消缓冲区滚动
#   - 周期性采样，判断真正的长期趋势
#   - 用法: sh longterm.sh start|stop|status|report [间隔秒]
# ============================================================================
D=/data/adb/f50_usbnet_guard
OUT=$D/longterm.log
ST=$D/lt.state
PIDF=$D/lt.pid
INT=60

# 累积偏移量持久化(跨进程重启不丢)
ls_off() { cat $ST.off 2>/dev/null || echo 0; }
ts_off() { cat $ST.off2 2>/dev/null || echo 0; }
ls_last() { cat $ST.last 2>/dev/null || echo 0; }
ts_last() { cat $ST.last2 2>/dev/null || echo 0; }

case "$1" in
stop)
  pkill -f "longterm.sh" 2>/dev/null
  rm -f $PIDF
  echo "longterm stopped"
  exit 0 ;;
status)
  echo "监控进程: $(pgrep -f lt.sh | tr '\n' ' ')  锁PID=$(cat $PIDF 2>/dev/null)"
  echo "采样间隔: ${INT}s   日志: $OUT"
  echo "采样行数: $(wc -l < $OUT 2>/dev/null)"
  echo "起止时间: $(head -1 $OUT 2>/dev/null | cut -d'|' -f1)  ~  $(tail -1 $OUT 2>/dev/null | cut -d'|' -f1)"
  exit 0 ;;
esac

# ---- 单实例锁 ----
if ! mkdir "$D/lt.lock" 2>/dev/null; then
  old=$(cat $PIDF 2>/dev/null)
  if [ -n "$old" ] && kill -0 "$old" 2>/dev/null; then
    echo "already running pid=$old"; exit 0
  fi
  rm -rf "$D/lt.lock"; mkdir "$D/lt.lock" 2>/dev/null
fi
echo $$ > $PIDF
trap 'rm -rf "$D/lt.lock"; exit 0' TERM INT

[ -f $OUT ] || echo "$(date '+%F %T')|# 起始: ifindex=$(cat /sys/class/net/eth0/ifindex 2>/dev/null)" > $OUT

# 初始化基线
ls_last=$(dmesg | grep -ac 'reset SuperSpeed')
ts_last=$(dmesg | grep -ac 'Tx status -71')
echo "$ls_last" > $ST.last; echo 0 > $ST.off
echo "$ts_last" > $ST.last2; echo 0 > $ST.off2
ls_off=0; ts_off=0
last_ix=$(cat /sys/class/net/eth0/ifindex 2>/dev/null)
last_ca=$(cat /sys/class/net/eth0/carrier 2>/dev/null)
last_pkt=$(cat /sys/class/net/eth0/statistics/tx_packets 2>/dev/null)

while true; do
  # 单调累加
  cr=$(dmesg | grep -ac 'reset SuperSpeed'); [ -z "$cr" ] && cr=0
  ct=$(dmesg | grep -ac 'Tx status -71');    [ -z "$ct" ] && ct=0
  [ "$cr" -lt "$ls_last" ] && ls_off=$((ls_off + ls_last - cr)); ls_last=$cr
  [ "$ct" -lt "$ts_last" ] && ts_off=$((ts_off + ts_last - ct)); ts_last=$ct
  echo "$cr" > $ST.last; echo "$ls_off" > $ST.off
  echo "$ct" > $ST.last2; echo "$ts_off" > $ST.off2
  tot_r=$((cr + ls_off)); tot_t=$((ct + ts_off))

  ix=$(cat /sys/class/net/eth0/ifindex 2>/dev/null)
  ca=$(cat /sys/class/net/eth0/carrier 2>/dev/null)
  pkt=$(cat /sys/class/net/eth0/statistics/tx_packets 2>/dev/null)
  err=$(cat /sys/class/net/eth0/statistics/tx_errors 2>/dev/null)
  car_err=$(cat /sys/class/net/eth0/statistics/tx_carrier_errors 2>/dev/null)
  rx_err=$(cat /sys/class/net/eth0/statistics/rx_errors 2>/dev/null)
  drop=$(cat /sys/class/net/eth0/statistics/tx_dropped 2>/dev/null)
  memb=$(ls /sys/class/net/br0/brif/ 2>/dev/null | tr '\n' ',')

  ix_chg=0; [ "$ix" != "$last_ix" ] && ix_chg=1 && last_ix=$ix
  ca_chg=0; [ "$ca" != "$last_ca" ] && ca_chg=1 && last_ca=$ca
  pkt_rate=0; [ -n "$pkt" ] && [ -n "$last_pkt" ] && pkt_rate=$(( (pkt - last_pkt) ))
  [ -n "$pkt" ] && last_pkt=$pkt

  echo "$(date '+%F %T')|r=$tot_r|t=$tot_t|ix=$ix($ix_chg)|ca=$ca($ca_chg)|pkt=$pkt|d=$pkt_rate|e=$err|ce=$car_err|re=$rx_err|dr=$drop|br=$memb" >> $OUT
  n2=0; while [ $n2 -lt 12 ]; do sleep 5; n2=$((n2+1)); done
done
