#!/system/bin/sh
# ============================================================================
# post-fs-data.sh —— 早期初始化(仅建目录/写默认配置，不动网络)
# 说明：USB 枚举发生在此阶段之后，真正的检测/复位交给 service.sh
# ============================================================================
MODDIR=${0%/*}
export MODDIR
. "$MODDIR/common.sh"

mkdir -p "$DATA_DIR" "$STATE" 2>/dev/null

# 首次运行写入默认配置(后续可编辑，不会被覆盖)
if [ ! -f "$CONF" ]; then
  cat > "$CONF" <<EOF
# f50_usbnet_guard 配置(改完下一轮巡检生效)
# USB 设备路径: /sys/bus/usb/devices/<USB_DEV>
USB_DEV=$USB_DEV
IFACE=$IFACE
BRIDGE=$BRIDGE
# xhci 控制器 platform 设备名 / 驱动名(最后手段: 强制重新枚举USB总线)
USB_XHCI=$USB_XHCI
USB_XHCI_DRV=$USB_XHCI_DRV
# br0 应拥有的地址(以 / 前 IP 判断)
BRIDGE_CIDR=$BRIDGE_CIDR
# 开机后等待系统自行枚举/桥接的最长时间(秒)
BOOT_WAIT=$BOOT_WAIT
# 开机后多少秒开始运行中巡检(秒)
BOOT_GRACE=$BOOT_GRACE
# 运行中巡检间隔(秒)
POLL=$POLL
# 两次恢复最小间隔(秒)
COOLDOWN=$COOLDOWN
# 巡检间隔内 Tx 错误增量阈值(旧口径, v1.5.0 仅显示用)
TXERR_DELTA=$TXERR_DELTA
# ==== v1.5.0 新增: Tx 判定改用"错误率 + 双下限" ====
# 实测正常流量下累积错误率仅 0.11%(99/90391)，旧口径 TXERR_DELTA=50
# 会每 ~52 秒误判一次(8.9h 误报 37 次)。下面三项共同生效。
TXERR_RATE=$TXERR_RATE
TXERR_MIN=$TXERR_MIN
PKT_MIN=$PKT_MIN
# 是否自动恢复(1/0)
AUTO_RESET=$AUTO_RESET
# 是否监控内核 USB 错误(r8152 Tx status -71)(1/0)
KLOG_DETECT=$KLOG_DETECT
# 内核错误轮询间隔(秒)
KLOG_POLL=$KLOG_POLL
# 是否允许"重启 netd"来恢复 DHCP(较激进,会短暂断网,1/0)
DHCP_RECOVER=$DHCP_RECOVER
# 内存碎片守卫: order-3 阈值 / page allocation failure 侦测(1/0)
MEM_GUARD=$MEM_GUARD
# ==== v1.5.1 新增: 内存调优(r8152 收包需 order-3 连续内存) ====
# DMA32 order-3 空闲块 <=此值即触发内存整理(旧版硬编码 5, 太迟钝)
MEM_ORDER3_MIN=$MEM_ORDER3_MIN
# min_free_kbytes (默认 4715 -> 16384, 给 GFP_ATOMIC 留余量)
MEM_MIN_FREE=$MEM_MIN_FREE
# watermark_scale_factor (默认 10 -> 50, 更早回收)
MEM_WATERMARK_SCALE=$MEM_WATERMARK_SCALE
# watermark_boost_factor (默认 0 -> 15000, 碎片后抬水位)
MEM_WATERMARK_BOOST=$MEM_WATERMARK_BOOST
# 定期重申上述 vm 参数, 防被系统/其它模块改回(1/0)
MEM_PERSIST=$MEM_PERSIST
# 对 eth0/USB 设备关闭 USB 自动挂起(Runtime PM)(1/0)
AUTOSUSPEND_OFF=$AUTOSUSPEND_OFF
# 恢复链启用 USBDEVFS_RESET(需 bin/usbreset)(1/0)
USBDEVFS_RESET=$USBDEVFS_RESET
# 恢复链启用 USB 端口电源循环(hub PORT_POWER)(1/0)
USB_POWER_CYCLE=$USB_POWER_CYCLE
# ==== v1.5.0 新增: 是否把模块日志写进 /dev/kmsg ====
# 建议保持 0: 模块自身依赖扫描 dmesg，往 kmsg 灌日志会污染输入源并拖慢巡检
KMSG_LOG=$KMSG_LOG
EOF
fi

[ -f "$DATA_DIR/reset_count" ] || echo 0 > "$DATA_DIR/reset_count"

# v1.5.0: 升级安装时补齐新增配置项(仅追加缺失项，不覆盖用户已有配置)
if [ -f "$CONF" ]; then
  grep -q '^TXERR_RATE=' "$CONF" || echo "TXERR_RATE=5" >> "$CONF"
  grep -q '^TXERR_MIN='  "$CONF" || echo "TXERR_MIN=100" >> "$CONF"
  grep -q '^PKT_MIN='    "$CONF" || echo "PKT_MIN=5000" >> "$CONF"
  grep -q '^KMSG_LOG='  "$CONF" || echo "KMSG_LOG=0" >> "$CONF"
  grep -q '^MEM_GUARD=' "$CONF" || echo "MEM_GUARD=1" >> "$CONF"
  grep -q '^MEM_ORDER3_MIN='      "$CONF" || echo "MEM_ORDER3_MIN=30"      >> "$CONF"
  grep -q '^MEM_MIN_FREE='        "$CONF" || echo "MEM_MIN_FREE=16384"     >> "$CONF"
  grep -q '^MEM_WATERMARK_SCALE=' "$CONF" || echo "MEM_WATERMARK_SCALE=50" >> "$CONF"
  grep -q '^MEM_WATERMARK_BOOST=' "$CONF" || echo "MEM_WATERMARK_BOOST=15000" >> "$CONF"
  grep -q '^MEM_PERSIST='         "$CONF" || echo "MEM_PERSIST=1"          >> "$CONF"
fi
# 尽早尝试关闭 USB 自动挂起(设备可能尚未枚举, 之后 service/巡检会反复补上)
disable_autosuspend
# v1.5.1: 尽早应用内存调优(早期一次, service.sh 启动后会再重申)
apply_mem_tuning
log "post-fs-data 完成: 数据目录 $DATA_DIR"
exit 0