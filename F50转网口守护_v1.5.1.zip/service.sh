#!/system/bin/sh
# ============================================================================
# service.sh —— 主守护 (late_start 由 Magisk 启动)  v1.5.0
# 开机自检 + 运行中巡检 + 内核USB错误监控；网口"消失/半死"自动逐级复位
# ----------------------------------------------------------------------------
# v1.5.0 核心修复(2026-10-09，基于实测 guard.log + dmesg):
#
#  【根因】"Tx 错误激增"判定用的是"绝对增量 > 50"，而 F50 转网口在正常业务
#         流量下的累积错误率只有 0.11%(实测 99/90391，rx_errors=0、
#         tx_dropped=0、collisions=0、carrier 恒为 1)。也就是说网卡完全健康，
#         但每约 52 秒就会跨过 50 这个阈值一次，v1.4.0 在 8.7 小时里误报 37 次。
#
#  【放大】触发后执行 do_recover()，虽然 carrier=1 时 recover_iface 会直接
#         返回、不动 USB，但 last_tx 被强制清零(见下方旧版代码)，使得下一轮
#         巡检必然再次满足条件 → 每轮都进 do_recover → 刷日志 + 写 module.prop
#         + 污染 last_reset/reset_count(把 37 次误判算成 41 次"复位")。
#
#  【修复】
#   1. Tx 判定改用"错误率 + 双重下限"(TXERR_RATE / TXERR_MIN / PKT_MIN)，
#      杜绝小分母下的偶发错误误判。
#   2. 无论是否越过阈值，基线一律同步为当前实测值(last_tx/last_pk = tx/pk)，
#      不再用 last_tx=0 制造"必然再次触发"。
#   3. Tx 错误越阈值只告警、不触发恢复。理由：真正的 USB 硬件故障一定会
#      在 carrier 掉线或内核 Tx status -71 上体现，由这两条路径负责复位；
#      链路正常时的 MAC 层发送失败不该动 USB。
# ============================================================================
MODDIR=${0%/*}
export MODDIR
. "$MODDIR/common.sh"
load_conf
mkdir -p "$DATA_DIR" "$STATE" 2>/dev/null

# ---------------- 命令行(排障用) ----------------
case "$1" in
  --status)  show_status; exit 0 ;;
  --recover) do_recover "手动触发"; show_status; exit 0 ;;
  --desc)    update_description; exit 0 ;;
  --run)     : ;;
esac

# ---------------- 单实例(mkdir 原子锁；$LOCKD 在 tmpfs，重启自动清空) ----------------
if ! mkdir "$LOCKD" 2>/dev/null; then
  old=$(cat "$LOCKD/pid" 2>/dev/null)
  if [ -n "$old" ] && kill -0 "$old" 2>/dev/null; then
    echo "已运行中 pid=$old"; exit 0
  fi
  rm -rf "$LOCKD"; mkdir "$LOCKD" 2>/dev/null
fi
echo $$ > "$LOCKD/pid"
chmod 700 "$LOCKD" 2>/dev/null
trap 'rm -rf "$LOCKD"; exit 0' TERM INT

update_description
log "==== f50_usbnet_guard v$MODVER 启动 (pid=$$) ===="
log "参数: USB=$USB_DEV IFACE=$IFACE BRIDGE=$BRIDGE 巡检=${POLL}s 冷却=${COOLDOWN}s 错误率阈值=${TXERR_RATE}% 内核监控=${KLOG_DETECT} DHCP恢复=${DHCP_RECOVER}"

# v1.5.1: 开机即应用内存调优(r8152 order-3 原子分配余量)
apply_mem_tuning
log "内存调优基线: min_free=$(cat /proc/sys/vm/min_free_kbytes 2>/dev/null) wsf=$(cat /proc/sys/vm/watermark_scale_factor 2>/dev/null) wbf=$(cat /proc/sys/vm/watermark_boost_factor 2>/dev/null) | DMA32 order-3=$(mem_order3)"

# ---------------- 等待系统启动完成 ----------------
wait_boot() {
  n=0
  while [ "$n" -lt "$BOOT_WAIT" ]; do
    [ "$(getprop sys.boot_completed)" = "1" ] && return 0
    sleep 2; n=$((n+2))
  done
  return 1
}

# ---------------- 开机自检 ----------------
boot_check() {
  log "开机自检: 等待转网口就绪(eth0链路 + br0 IP + dnsmasq)，最多 ${BOOT_GRACE}s ..."
  n=0
  while [ "$n" -lt "$BOOT_GRACE" ]; do
    if iface_link_ok && in_bridge && br0_has_ip && dhcp_pid >/dev/null; then
      log "开机就绪: eth0 链路 + br0 IP + DHCP 全部正常"
      disable_autosuspend
      update_description; return 0
    fi
    if iface_broken; then
      log "开机: 检测到网口半死(无 carrier)，立即恢复"
      [ "$AUTO_RESET" = "1" ] && do_recover "开机: 网口半死"
      return 0
    fi
    sleep 3; n=$((n+3))
  done
  log "开机转网口 ${BOOT_GRACE}s 仍未就绪 → 触发恢复"
  [ "$AUTO_RESET" = "1" ] && do_recover "开机后网络未就绪"
  update_description
}

# ---------------- 运行中巡检 ----------------
loop() {
  kticks=$(( KLOG_POLL / POLL )); [ "$kticks" -lt 1 ] && kticks=1
  log "进入巡检 (间隔 ${POLL}s, 开机宽限 ${BOOT_GRACE}s, 内核错误轮询 ${KLOG_POLL}s/实际$((kticks * POLL))s)"
  sleep "$BOOT_GRACE"
  last_tx=$(tx_errors); [ -z "$last_tx" ] && last_tx=0
  last_pk=$(tx_packets); [ -z "$last_pk" ] && last_pk=0
  last_usberr=$(usb_err_count)
  hb=0
  ktick=0
  link_logged=0
  dhcp_logged=0
  last_m71=0
  last_mvb=0
  last_mtp=0
  last_compact=0
  last_memapply=0
  last_allocfail=$(page_alloc_fail); [ -z "$last_allocfail" ] && last_allocfail=0
  now_s=0
  last_storm=-600
  while true; do
    if ! iface_exists; then
      [ "$AUTO_RESET" = "1" ] && do_recover "巡检: 网口消失"
      last_tx=0; last_pk=0
    elif iface_broken; then
      [ "$AUTO_RESET" = "1" ] && do_recover "巡检: 网口半死(无 carrier)"
      last_tx=0; last_pk=0
    elif ! iface_link_ok; then
      # carrier=0 但接口可操作 → 可能是真没接设备：仅在状态变化时记录一次
      if [ "$link_logged" = 0 ]; then
        log "巡检: $IFACE carrier=0 (链路断开,视为未接网线,不触发复位)"
        link_logged=1
      fi
    elif ! in_bridge; then
      link_logged=0
      fix_bridge; update_description
    elif ! br0_has_ip; then
      link_logged=0
      recover_bridge_ip; update_description
    else
      link_logged=0
      disable_autosuspend

      # ---- v1.5.0: 错误率判定，且只告警不恢复 ----
      tx=$(tx_errors);  [ -z "$tx" ] && tx=0
      pk=$(tx_packets); [ -z "$pk" ] && pk=0
      # 计数器回绕(网卡被重新枚举)时同步基线，避免算出巨大的假增量
      if [ "$tx" -lt "$last_tx" ] 2>/dev/null; then last_tx=$tx; fi
      if [ "$pk" -lt "$last_pk" ] 2>/dev/null; then last_pk=$pk; fi
      dtx=$((tx - last_tx)); [ "$dtx" -lt 0 ] && dtx=0
      dpk=$((pk - last_pk));  [ "$dpk" -lt 0 ] && dpk=0
      if [ "$dtx" -ge "$TXERR_MIN" ] 2>/dev/null && [ "$dpk" -ge "$PKT_MIN" ] 2>/dev/null; then
        rate=$((dtx * 100 / dpk))
        if [ "$rate" -ge "$TXERR_RATE" ] 2>/dev/null; then
          # 链路正常(carrier=1)时的 MAC 层发送失败≠USB 故障，不动 USB。
          # 真正的 USB 故障会由 carrier 掉线或内核 Tx status -71 触发复位。
          log "警告: Tx 错误率 ${rate}% (+$dtx/$dpk) 超阈值，但 carrier=1 链路正常 → 仅记录不恢复"
        fi
      fi
      # 无论是否越阈值都同步基线（v1.4.0 在此写 last_tx=0，导致每轮必然再触发）
      last_tx=$tx; last_pk=$pk

      if ! dhcp_pid >/dev/null; then
        if [ "$dhcp_logged" = 0 ]; then
          recover_dhcp
          dhcp_logged=1
        fi
        update_description
      else
        dhcp_logged=0
      fi
    fi

    # 内核 USB 错误监控
    if [ "$KLOG_DETECT" = "1" ]; then
      ktick=$((ktick + 1))
      if [ "$ktick" -ge "$kticks" ]; then
        ktick=0
        cur=$(usb_err_count)
        if [ -n "$cur" ] && [ "$cur" -gt "$last_usberr" ] 2>/dev/null; then
          log "内核: r8152 USB 错误新增 $((cur-last_usberr)) 次 (累计 $cur)"
          last_usberr=$cur
        fi
      fi
    fi

    # —— 环境监视: 只在变化时落一行(最小化写盘), 抓下一次故障现场 ——
    now_s=$(date +%s)
    m71=$(dmesg 2>/dev/null | grep -ac 'Tx status -71'); [ -z "$m71" ] && m71=0
    mvb=$(dmesg 2>/dev/null | grep -a charger-manager | grep -aoE 'vbus: [0-9]+' | tail -1 | tr -dc '0-9'); [ -z "$mvb" ] && mvb=$last_mvb
    mtp=$(for z in /sys/class/thermal/thermal_zone*; do cat "$z/temp" 2>/dev/null; done | sort -rn | head -1); [ -z "$mtp" ] && mtp=$last_mtp
    d71=$((m71 - last_m71)); dvb=$((mvb - last_mvb)); dtp=$((mtp - last_mtp))
    if [ "$d71" -ge 5 ] && [ "$((now_s - last_storm))" -ge 600 ]; then
      last_storm=$now_s
      rsrp=$(dumpsys telephony.registry 2>/dev/null | grep -aoE 'ssRsrp = -?[0-9]+' | grep -vE '2147483647' | head -1 | grep -oE '\-?[0-9]+')
      log "!! USB 错误风暴: Tx-71 +$d71/$((kticks*POLL))s (累计 $m71) — 现场: RSRP=${rsrp:-?}dBm 最高温=$((mtp/1000))C vbus=$((mvb/1000))mV carrier=$(iface_carrier) tx_err=$(tx_errors) rx_err=$(cat /sys/class/net/$IFACE/statistics/rx_errors 2>/dev/null)"
    elif [ "$dvb" -ge 100000 ] || [ "$dvb" -le -100000 ] || [ "$dtp" -ge 3000 ] || [ "$dtp" -le -3000 ]; then
      log "环境: vbus=$((mvb/1000))mV 最高温=$((mtp/1000))C (Δvbus=$((dvb/1000))mV Δ温=${dtp}mC)"
    fi
    last_m71=$m71; last_mvb=$mvb; last_mtp=$mtp

    # —— 内存碎片守卫 v2 (v1.5.1): r8152 收包要 32KB 连续内存(order-3), 耗尽即掉网卡 ——
    if [ "$MEM_GUARD" = "1" ]; then
      # (1) 周期性重申 VM 调优, 防被系统/其它模块改回
      if [ "$MEM_PERSIST" = "1" ] && [ "$((now_s - last_memapply))" -ge 300 ]; then
        last_memapply=$now_s
        apply_mem_tuning
      fi
      # (2) 碎片 / order-3 原子分配失败侦测 → 立即内存整理
      n3=$(mem_order3); case "$n3" in ''|*[!0-9]*) n3=9999 ;; esac
      pf=$(page_alloc_fail); [ -z "$pf" ] && pf=0
      trigger=0; why=""
      [ "$n3" -le "$MEM_ORDER3_MIN" ] && { trigger=1; why="order-3=$n3<=$MEM_ORDER3_MIN"; }
      [ "$pf" -gt "$last_allocfail" ] && { trigger=1; why="$why page_alloc_new+$((pf-last_allocfail))"; }
      last_allocfail=$pf
      if [ "$trigger" = "1" ] && [ "$((now_s - last_compact))" -ge 120 ]; then
        last_compact=$now_s
        echo 1 > /proc/sys/vm/compact_memory 2>/dev/null
        n3b=$(mem_order3)
        log "内存碎片: $why → 已触发内存整理 → order-3=$n3b (阈值$MEM_ORDER3_MIN, 限2分钟一次)"
      fi
    fi

    # 心跳(30 分钟一条，减少 guard.log 的持续落盘；事件日志不受影响)
    hb=$((hb+1))
    if [ "$hb" -ge 120 ]; then
      hb=0
      log "[心跳] iface=$(iface_exists && echo y || echo n) broken=$(iface_broken && echo y || echo n) carrier=$(iface_carrier) bridge=$(in_bridge && echo y || echo n) ip=$(br0_has_ip && echo y || echo n) dhcp=$(dhcp_pid) usberr=$(usb_err_count)"
    fi

    update_description
    sleep "$POLL"
  done
}

wait_boot
boot_check
loop